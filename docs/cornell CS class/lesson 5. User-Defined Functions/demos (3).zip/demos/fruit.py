"""
A module with a fruitful function definition.
Notice that what is after the return is ignored.

Author: Walker M. White (wmw2)
Date:   February 14, 2019
"""

def plus(n):
    """
    Returns n+1
    """
    x = n+1
    return x
