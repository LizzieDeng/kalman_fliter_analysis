class class_name(object):
    """Class specification"""

    # getters and setters

    # initializer (__init__)

    # special methods (__str__, __repr__)

    # other method definitions

    # anything else
