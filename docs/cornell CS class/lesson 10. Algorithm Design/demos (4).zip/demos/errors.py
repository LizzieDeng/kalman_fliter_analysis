"""
A module with two syntax errors in it

Watch what happens when you try to import this module.

Author: Walker M. White
Date:   February 14, 2019
"""


def func(x):
    """
    Returns: the next number after x

    Precondition: x is a number
    """
    return x+1


y = func(3)
print(y)
