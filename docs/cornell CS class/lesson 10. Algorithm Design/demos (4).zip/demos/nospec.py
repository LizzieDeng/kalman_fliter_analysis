"""
A module with an unimplemented function

This module shows what happens when the specification is missing.

Author: Walker M. White
Date:   February 14, 2019
"""
import introcs


def last_name_first(n):
    # implement me
    pass
