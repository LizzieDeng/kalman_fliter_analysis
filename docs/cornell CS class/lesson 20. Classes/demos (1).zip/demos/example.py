"""
A module with a simplest class possible.

Author: Walker M. White (wmw2)
Date:   October 1, 2017 (Python 3 Version)
"""


class Example(object):
    """
    Instances of this class do nothing
    """
    pass
