class class_name(object):
    """Class specification"""

    # assignment statements

    # functions definitions

    # (other statements possible)
