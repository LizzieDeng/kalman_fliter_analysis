"""
Module to demonstrate how to modify a list in a for-loop.

This function is a stub and is not complete

Author: Walker M. White (wmw2)
Date:   May 24, 2019
"""


def add_one(lst):
    """
    (Procedure) Adds 1 to every element in the list

    Example: If a = [1,2,3], add_one(a) changes a to [2,3,4]

    Parameter lst: The list to modify
    Precondition: lst is a list of all numbers (either floats
    or ints), or an empty list
    """
    # procedure; no return
