"""
A first attempt at hello, without range.

This module does NOT contain valid Python and will fail to import

Author: Walker M. White
Date:   April 15, 2019
"""


def hello(n):
    """
    Prints 'Hello World' n times

    Parameter n: Number of times to say hello
    Precondition: n > 0 is an int.
    """
    lst = [1, 2, …, n]

    for x in lst:
        print('Hello World')
