"""
A first attempt at print_each, without loops.

This module does NOT contain valid Python and will fail to import

Author: Walker M. White
Date:   April 15, 2019
"""


def print_each(text):
    """
    Prints each character of text on a line by itself

    Example: print_each('abc') displays
        a
        b
        c

    Parameter text: The string to split up
    Precondition: text is a string
    """
    x = text[0]
    print(x)
    x = test[1]
    print(x)
    …
    x = text[len(text)-1]
    print(x)
