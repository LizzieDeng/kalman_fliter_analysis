"""
A module with with two list functions.

These functions are stubs and are not complete

Author: Walker M. White
Date:   April 15, 2019
"""


def sum(lst):
    """
    Returns: the sum of all elements in the list

    Example: sum([1,2,3]) returns 6
             sum([5]) returns 5

    Parameter lst: the list to sum
    Precondition: lst is a nonempty list of numbers
    (either floats or ints)
    """
    # Create a variable to hold result (start at 0)
    # Add each list element to variable
    # Return the variable


def num_ints(lst):
    """
    Returns: the number of ints in the list

    Example: num_ints([1,2.0,True]) returns 1

    Parameter lst: the list to count
    Precondition: lst is a list of any mix of types
    """
    # Create a variable to hold result (start at 0)
    # for each element in the list…
        # check if it is an int
        # add 1 if it is
    # Return the variable
