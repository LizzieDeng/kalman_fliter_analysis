"""
An interactive script.

This script shows how to use the
input function to read strings.

Author: Walker M. White (wmw2)
Date:   July 31, 2018
"""

x = input('Type something: ')
print('You typed: '+str(y))
