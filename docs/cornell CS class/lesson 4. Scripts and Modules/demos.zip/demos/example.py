"""
A simple module.

This file shows how modules work

Author: Walker M. White (wmw2)
Date:   August 25, 2017 (Python 3 Version)
"""

x = 1+2    # I am a comment
x = 3*x
x