"""
An interactive script.

This script shows how to use the
input function to read numbers.

Author: Walker M. White (wmw2)
Date:   July 31, 2018
"""

x = input('Give me a number: ')
x = int(x)
y = x+1
print('The next number is '+str(y))
