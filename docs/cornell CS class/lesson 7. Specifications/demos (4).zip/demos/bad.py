"""
A module with a badly specified function

Author: Walker M. White
Date:   February 14, 2019
"""
import introcs


def number_vowels(w):
    """
    Returns: number of vowels in string w.

    Parameter w: The text to check for vowels
    Precondition: w string w/ at least one letter and only letters
    """
    # We will implement this later
